include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
end

function ENT:Think()
end

function ENT:OnRemove()
end
